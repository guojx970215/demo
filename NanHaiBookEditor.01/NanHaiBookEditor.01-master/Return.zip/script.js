var wordTime = {"w1": {start: 0.86,end: 3.17},
"w2": {start: 3.18,end: 4.64},
"w3": {start: 4.65,end: 10.22},
"w4": {start: 10.23,end: 11.68},
"w5": {start: 11.69,end: 14.22},
"w6": {start: 14.23,end: 16.46}
};